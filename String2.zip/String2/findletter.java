public class findletter {

    
    public static void main(String[] args) {
        String word = "umrella";
        char letterToCheck = 'm';

        int index = word.indexOf(letterToCheck);

        if (index != -1) {
            System.out.println("The letter '" + letterToCheck + "' is present. ");
        } else {
            System.out.println("The letter '" + letterToCheck + "' is not present in the word.");
        }
    }
}
