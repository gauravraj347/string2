public class stringlength {

    public static void main(String[] args) {
        String str="refrigeratoe";
        int res=str.length();
        System.out.println(res);
    }
}