
public class deletcon {

    public static void main(String[] args) {
        String sentence = "Hello, hava a good boy";

        String result = removeConsonants(sentence);

    
        System.out.println("Original sentence: " + sentence);
        System.out.println("After removing consonants: " + result);
    }

    private static String removeConsonants(String input) {
        StringBuilder result = new StringBuilder();

        for (char ch : input.toCharArray()) {
            if (isVowel(ch) || Character.isWhitespace(ch)) {
                result.append(ch);
            }
        }

        return result.toString();
    }

    private static boolean isVowel(char ch) {
        ch = Character.toLowerCase(ch);
        return ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u';
    }
}
